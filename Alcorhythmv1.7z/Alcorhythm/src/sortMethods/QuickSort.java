package sortMethods;

import java.util.Arrays;
import java.util.List;

public class QuickSort {
    public static List<Integer> quickSort(List<Integer> arr) {
        return null;
    }

    public static void sort(Integer[] arr) {
        List<Integer> list = Arrays.asList(arr);

        quickSort(list).toArray(arr);
    }

}