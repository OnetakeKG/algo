//import java.util.Random;
//
//public class Fill {
//    public Fill() {
//    }
//    public static Object[] fillIt() {
//        final Random random = new Random();
//        String brands[]={"Lenuvo","Asos","MacNote","Eser","Xamiou",};
//        int random_number = (random.nextInt(40)+9)*50;
//        if (random_number>2000) random_number -=450;
//        int random_number2 = (random.nextInt(6)*4);
//        if (random_number2==0) random_number2 +=4;
////        arr [0] = random_number;
////        arr [1] = random_number2;
////        arr = brands[random.nextInt(5)];
////        return random_number; random_number2; arr;
//    };
//}
